var score = 0;
var holdScore = document.getElementById("score");
holdScore.innerHTML = score;
var gameStart = false;
var scorePoint = 2;

var lives = 3;
var holdLives = document.getElementById("lives")


var gameOver = false;
var gameStatus = document.getElementById("game-status");

var timer = 40;


var allEnemies = [];

var seconds = 60;

function countdown() {

    var startTick = 0;

    function tick(_sec) {
        var counter = document.getElementById("counter");

        seconds--;
        counter.innerHTML = "0:" + (seconds < 10 ? "0" : "") + String(seconds);
        if (seconds > 0) {
            this.startTick = setTimeout(tick, 1000);
        } else {
            alert("Game over");
        }
    }
    if (!gameStart) {
        clearTimeout(this.startTick);
    } else {
        tick(seconds);


    }
}

var Gems = function(x, y, filename) {

    this.sprite = 'images/' + filename;
    this.x = x;
    this.y = y;
}

Gems.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
}

Gems.prototype.update = function() {

}

function resetGems() {
    for (var i = 0; i < allGems.length; i++) {
        allGems[i].x = -200;
    }
}

var Enemy = function(x, y) {
    this.sprite = 'images/enemy-bug.png';
    this.x = x;
    this.y = y;
};


Enemy.prototype.update = function(dt) {
    if (this.x > 500) {
        this.x = Math.floor((Math.random() * 0) - 500);
        this.y = Math.floor((Math.random() * 200) + 50);
    } else {
        this.x = this.x + (Math.floor((Math.random() * 500) + 100) * dt);
    }

    checkCollision();

};

Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

var Player = function(x, y) {

    this.sprite = 'images/char-pink-girl.png';
    this.x = x;
    this.y = y;
}

Player.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

Player.prototype.update = function() {
    if (score > 5 && score < 10) {
        resetGems();
        allGems[0].x = 0;
    } else if (score > 10 && score < 15) {
        resetGems();
        allGems[1].x = 0;
    } else if (score > 15 && score < 20) {
        resetGems();
        allGems[2].x = 0;
    } else if (score == 20)

    {

    } else {

    }
}

function checkCollision() {
    for (var i = 0; i < allEnemies.length; i++) {
        if ((player.y > allEnemies[i].y - 50 && player.y < allEnemies[i].y + 50) && (player.x > allEnemies[i].x && player.x < allEnemies[i].x + 50)) {
            //console.log('u kapen');
            player.y = 370;

            if (score > 0) {
                score--;
                holdScore.innerHTML = score;
            }
            if (score === 0) {
                lives--;
                holdLives.innerHTML = lives;
            }

            if (lives == 0) {
                gameOver = true;
                $("#game-status").removeClass("hidden");
                start.innerHTML = 'Start';
            }
        } else if (score < 0) {

        }
    }
}

Player.prototype.handleInput = function(k) {

    if (gameStart) {
        if (k == "down") {
            if (this.y < 370) {
                this.y += 50;
            }

        } else if (k == "up") {
            if (this.y > 0) {
                this.y -= 50;

            } else {
                score += scorePoint;
                holdScore.innerHTML = score;
                player.y = 370;
            }
            if (score > 20) {
                alert("YOU WIN, CONGRATULATIONS!");
                document.location.reload();
            }

        } else if (k == "left") {
            if (this.x > 0) {
                this.x -= 50;
            }
        }

        if (k == "right") {
            if (this.x < 370) {
                this.x += 50;
            }
        }
    }

}

var start = document.getElementById('start');
start.addEventListener("click", startGame);

function startGame() {
    if (gameStart) {
        start.innerHTML = 'Start';
        gameStart = false;
        gameOver = true;

    } else {
        if (gameOver) {
            gameOver = false;
            $("#game-status").addClass("hidden");
            lives = 3;
        }
        player = new Player(200, 370);
        allEnemies = [new Enemy(-100, 220, 30), new Enemy(-100, 120, 25), new Enemy(-100, 50, 40), new Enemy(-100, 75, 130)];
        gameStart = true;
        holdLives.innerHTML = lives;
        start.innerHTML = 'Stop';
    }
    countdown();
}

var player = new Player(200, 370);

var allGems = [new Gems(-200, 350, 'Gem-Orange.png'), new Gems(-200, 350, 'Gem-Blue.png'), new Gems(-200, 350, 'Gem-Green.png')];

document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});