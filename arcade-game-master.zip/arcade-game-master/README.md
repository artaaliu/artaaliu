#**Arcade-Game**

##Let's Have Some Fun..!

######We have a game here which contain a player and enemies(bugs). In this game the player should cross over to the other-side without taching bugs.

----------------------

##Deatils of the game:

*The player can move left, rigth, up and down by using the arrow keys.
*The enemies are moving from left to right in threee lines.
*Once a player tauch the bug it will loose one(1)score,or if the score is zero(0) it will be loosing one(1)live, and after that the playerwillbe back at the starting position. But it the player has already one(1) live the game will be over.
*If the player cross the game and reach 5 scores or more than the player will win one(1)gem in orange, but if the player reach 10 scores or more than will win a gem in a blue color,but if the player is going to reach 15 scores or more will win a gem in green.
*And the goal for this game is to reach 50 to 55 scores to win the game.

----------------------

>Now you are welcome to start the game and try to have maximum of the scores.

**HAVE FUN!!